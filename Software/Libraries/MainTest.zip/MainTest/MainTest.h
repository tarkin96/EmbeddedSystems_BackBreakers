class MainTest {
  public: 
    int mainTest(void);
    bool full(void);
    bool empty(void);
    bool partialEmpty(void);
    bool unknownTag(void);

};
