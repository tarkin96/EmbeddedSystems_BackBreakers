#include "MainTest.h"
#include "speaker.h"
#include "RFID_Reader.h"
Speaker speakertest = Speaker();
//RFID_Reader readerTest(10);
int buttonstateTest = 0;
const int buttonPin = PUSH2;

int MainTest::mainTest(void) {
    buttonstateTest = digitalRead(buttonPin);
    if(buttonstateTest == 1) {
      Serial.println("Button pressed, starting tests.");
      delay(5000);
      if(full()) Serial.println("All tags have been read and checked successfully. Make sure speaker played postive tone.");
      else Serial.println("There was an error with checking if all tags have been read.");
      delay(5000);
      if(empty()) Serial.println("All tags are missing. (Correct operation). Make sure speaker played negative tone.");
      else Serial.println("There was an error with making sure no tags have been read.");
      delay(5000);
      if(partialEmpty()) Serial.println("Only some tags have been read correctly (Correct operation).Make sure speaker played negative tone.");
      else Serial.println("There was an error with reading a partial amount of tags.");
      delay(5000);
      if(unknownTag()) Serial.println("An unknown tag was read and the reader rejected it (Correct operation).Make sure speaker played negative tone.");
      else Serial.println("There was an error with reading a unknown tag.");
    }
}

bool MainTest::full(void) {
  RFID_Reader r(10);
  //for (int i = 0; i < 10; i++) {
  r.checkTagID("1E009A4067A3");
  r.checkTagID("010230F28243");
  r.checkTagID("01023C013A04");
  r.checkTagID("01023C0A4376");
  r.checkTagID("01023C000E31");
  r.checkTagID("01023C0A3207");
  r.checkTagID("1A004116317C");
  r.checkTagID("1E009A81F9FC");
  r.checkTagID("1A004162261F");
  r.checkTagID("1A004162261Z");
 // }
  if (r.runCheck()) {
    speakertest.playPositive();
    return true;
  }
  else {
    speakertest.playNegative();
    return false;
  }
}

bool MainTest::empty(void) {
  RFID_Reader r(10);
  
  if (r.runCheck()) {
    speakertest.playPositive();
    return false;
  }
  else {
    speakertest.playNegative();
    return true;
  };
}

bool MainTest::partialEmpty(void) {
  RFID_Reader r(10);
  r.checkTagID("01023C0A3207");
  r.checkTagID("1A004116317C");
  r.checkTagID("1E009A81F9FC");
  r.checkTagID("1A004162261F");
  r.checkTagID("1A004162261Z");

  if (r.runCheck()) {
    speakertest.playPositive();
    return false;
  }
  else {
    speakertest.playNegative();
    return true;
  };
}

bool MainTest::unknownTag(void) {
  RFID_Reader r(10);
  r.checkTagID("AAAAAAAAAAAA");

  if (r.runCheck()) {
    speakertest.playPositive();
    return false;
  }
  else {
    speakertest.playNegative();
    return true;
  };
}

