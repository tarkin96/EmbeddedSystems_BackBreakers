#include <Energia.h>
#ifndef RFID_READER_H
#define RFID_READER_H

#define RFIDResetPin P4_3
#define LED_PIN P3_0 
#define READ 1
#define EDIT 0


#include <Energia.h>
class RFID_Reader {
  public:
   RFID_Reader(int);
   int checkTagID(char *);
   bool runCheck();
   void resetReader();
   char* processTag();
   void successNotify();
   void setChecked(int* newCheck);
   void setUnchecked(int* newUnchecked);
   int* getChecked();
   int* getUnchecked();
   void changeMode();
   int getMode();
   bool isModeRead();
   bool isModeEdit();
   int addOrRemove(char * currentTag);
   bool isTagRegistered(char * currentTag);
  private:
    char ** trackList;
    int * checked;
    int * unchecked;
    int trackTotal;
    int currentMode;
    char* tagString;
};
#endif
