#include "RFID_Reader.h"
#include <stdlib.h>
#include <string.h>

RFID_Reader::RFID_Reader(int num) {
  //Intialize Tags List 
  trackList = (char**)malloc(sizeof(char*) * num);
  for (int i = 0; i < num; i++) {
    trackList[i] = (char*)malloc(sizeof(char) * 13);
  }
  trackList[0] = "5600525DAAF3";
  trackList[1] = "5600920EDB11";
  trackList[2] = "56009243AF28";
  trackList[3] = "5600525D732A";
  trackList[4] = "5600924340C7";
  trackList[5] = "560092438007";
  trackList[6] = "560091F3A793";
  trackList[7] = "5600525E1B41";
  trackList[8] = "560091F37642";
  trackList[9] = "5600525D98C1";

  //Initialize Check and unchecked list
  int i;
  checked = (int*)malloc(sizeof(int) * num);
  unchecked = (int*)malloc(sizeof(int) * num);
  for(i = 0 ; i < num; i++){
    checked[i] = -1;
    unchecked[i] = i;
  }
  trackTotal = 5;
  currentMode = READ;
  tagString = (char*)malloc(sizeof(char) * 13);
}

int RFID_Reader::checkTagID(char * currentTag) {
  int i;
  int j;
  for(i = 0; i < trackTotal; i++){
    if(strcmp(currentTag,trackList[i]) == 0){
       if(checked[i] == i){
          checked[i] = -1;
          unchecked[i] = i;
          return -1;
       }
      else if (unchecked[i] == i){
        unchecked[i] = -1;
        checked[i] = i;
        return 1;
      }  
    }
  }
  return 0;
}

bool RFID_Reader::runCheck() {
  int i;
  for(i = 0; i < trackTotal; i++){
    if(checked[i] == -1){
      return false;
    }
  }
  return true;
  
}

void RFID_Reader::resetReader() {
///////////////////////////////////
//Reset the RFID reader to read again.
///////////////////////////////////
digitalWrite(RFIDResetPin, LOW);
digitalWrite(RFIDResetPin, HIGH);
delay(150);
  
}

void RFID_Reader::successNotify(){
  digitalWrite(LED_PIN, HIGH);   
  delay(1000);               
  digitalWrite(LED_PIN, LOW);    
  delay(1000);               
}

char* RFID_Reader::processTag(){
  int index = 0;
  boolean reading = false;
  
  while(Serial.available() > 0){
    int readByte = Serial.read(); //read next available byte
    if(readByte == 2){
     reading = true; //begining of tag
    }
    if(readByte == 3) reading = false; //end of tag

    if(reading && readByte != 2 && readByte != 10 && readByte != 13){
     //store the tag
      tagString[index] = readByte;
      index ++;
    }  
  }
  tagString[12] = '\0';
  return tagString;
}

void RFID_Reader::changeMode(){
	if(currentMode == READ){
		currentMode = EDIT;
	}
	else{
		currentMode = READ;
	}
}

int RFID_Reader::getMode(){
	return currentMode;
}

bool RFID_Reader::isModeEdit(){
	if(currentMode == EDIT){
		return true;
	}
	return false;
}

bool RFID_Reader::isModeRead(){
	if(currentMode == READ){
		return true;
	}
	return false;
}

bool RFID_Reader::isTagRegistered(char* currentTag){
	int i;
	for(i = 0; i < trackTotal; i++){
		if(strcmp(currentTag,trackList[i]) == 0){
			return true;
		}
	}
	return false;
}

int RFID_Reader::addOrRemove(char * currentTag){
	if(!isTagRegistered(currentTag)){
		checked[trackTotal] = trackTotal;
		unchecked[trackTotal] = -1;
		trackList[trackTotal] = currentTag;
		trackTotal++;
		return 1;
	}else{
		int toDelete = 0;
		int i;
		for(i = 0; i < trackTotal; i++){
    		if(strcmp(currentTag,trackList[i]) == 0){
    			char* temp = trackList[i];
    			trackList[i] = trackList[trackTotal-1];
    			trackList[trackTotal-1] = temp;
    		}
    	}	
    	trackTotal--;
    	return -1;
	}
}



void RFID_Reader::setChecked(int* newCheck){
  checked = newCheck;
}
void RFID_Reader::setUnchecked(int* newUnchecked){
  unchecked = newUnchecked;
}
int* RFID_Reader::getChecked(){
  return checked;
}
int* RFID_Reader::getUnchecked(){
  return unchecked;
}


