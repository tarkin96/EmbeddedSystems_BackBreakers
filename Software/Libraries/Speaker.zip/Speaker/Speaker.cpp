#include "speaker.h"

Speaker::Speaker(){
  
}

void Speaker::sleepSpeaker(){
  noTone(SpeakerPin);
}

void Speaker::playFreq(int freq, int elapsedTime){
  tone(SpeakerPin, freq, elapsedTime);
}

void Speaker::playEditMode(){
        playFreq(440, 500); 
        delay(100);  
        playFreq(349, 350);
        delay(100);  
        playFreq(523, 250);  
        delay(100);         
}

void Speaker::playReadMode(){
		playFreq(349, 250);  
        delay(100);        
        playFreq(415, 500);
        delay(100);  
        playFreq(349, 375); 
        delay(100);
}


void Speaker::playPositive(){
  for (int currentNote = 0; currentNote < 8; currentNote++) {

    int noteDuration = 1000 / positiveDurations[currentNote];
    playFreq(positiveFrequencies[currentNote], noteDuration);

    // to distinguish the notes, set a minimum time between them.
    // the note's duration + 30% seems to work well:
    int pause = noteDuration * 1.30;
    delay(pause);
    // stop the tone playing:
    sleepSpeaker();
  }
}

void Speaker::playNegative(){
   for (int currentNote = 0; currentNote < 8; currentNote++) {

    int noteDuration = 1000 / negativeDurations[currentNote];
    playFreq(negativeFrequencies[currentNote], noteDuration);

    // to distinguish the notes, set a minimum time between them.
    // the note's duration + 30% seems to work well:
    int pause = noteDuration * 1.30;
    delay(pause);
    // stop the tone playing:
    sleepSpeaker();
  }
}


