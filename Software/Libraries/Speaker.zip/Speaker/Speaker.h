/*
  speaker.h - library for controlling our speaker
  Created by Joe Hilbert, Wade King, and Kevin Fuentes
  Released into public domain
*/

#ifndef speaker_h
#define speaker_h

#define SpeakerPin P1_5 

static int positiveFrequencies[] = {
   262, 193, 193, 220, 193,0 , 247, 262
};

static int positiveDurations[] = {
  4, 8, 8, 4, 4, 4, 4, 4
};


static int negativeFrequencies[] = {
   256, 432, 256, 432, 256, 432, 256, 432
};

static int negativeDurations[] = {
  4, 4, 8, 4, 8, 4, 8, 4
};



#include "Energia.h"

class Speaker {
  public:

    /*
      Prereq: None
      Postreq: Speaker class instance is created
    */
    Speaker();

    /*
      Prereq: Speaker instance must not be null
      Postreq: Speaker is put into lowpower mode
    */
    void sleepSpeaker();

    /*
      Prereq: Speaker instance is not null
      Postreq: Speaker plays a positive tone
    */
    void playPositive();

    /*
      Prereq: Speaker instance is not null
      Postreq: Speaker class plays a negative tone
    */
    void playNegative();

    /*
      Prereq: Speaker instance is not null
      Postreq: Speaker plays the frequency thats passed in for the elapsedTime
    */
    void playFreq(int freq, int elapsedTime);
    
    void playEditMode();
    void playReadMode();

  private:
};

#endif
